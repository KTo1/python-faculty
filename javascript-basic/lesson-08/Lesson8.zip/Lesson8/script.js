// myFunc();
//
// function myFunc() {
//     console.log('Hello!')
// }
//
// myFunc();
// var a;
//
// console.log(a);
// // var a = 5;
// a = 5;
// console.log(a);
// 'use strict';
// c = 5;
//
// console.log(c);

// console.log(a);
//
// // if (true) {
// //     var a = 5;
// // }
// function foo() {
//     if (true) {
//         var a = 5;
//     }
// }
// foo();
//
// console.log(a);

// myFunc();
// var myFunc = function () {
//     console.log('Hello!');
// };
// myFunc();
// 'use strict';
// var d = 5;
// var result;

// if (d > 3) {
//     function result() {
//         console.log('>');
//     }
// } else {
//     function result() {
//         console.log('<=');
//     }
// }
// if (d > 3) {
//     result = function () {
//         console.log('>');
//     }
// } else {
//     result = function () {
//         console.log('<=');
//     }
// }
//
// result();

// let foo = function bar() {
//     bar();
// };
// foo();
// 'use strict';
// function foo() {
//     'use strict';
//     console.log(this);
// }
// function foo1() {
//     console.log(this);
// }
//
// // foo();
// // window.foo();
//
// foo();
// foo1();

// function foo() {
//     // 'use strict';
//     console.log(this);
// }
//
// var bar = foo;
//
// bar();

// var game = {
//     run() {
//         console.log(this);
//     }
// };
//
// // game.run();
// var bar = game.run;
//
// bar();
// 'use strict';
// var user = {
//     userName: 'Vasya',
//     sayName() {
//         console.log(this);
//     }
// }
// let z = 1;
// setTimeout(user.sayName, 1000); // ?
// setTimeout(user.sayName(), 1000); // ?
// setTimeout(function() { user.sayName() }, 1000); // ?
// 'use strict';
// var foo = (a, b) => {
//     console.log(this);
//     console.log(a, b);
//     let z = 4;
//     function bar() {
//
//         function baz() {
//             console.log(z);
//         //
//         //
//         //
//         //
//         //
//         }
//     }
//
// };
// function foo(a, b) {
//     console.log(this);
//     console.log(a, b);
// }
//
// var user = {
//     name: 'Vasya',
// }
//
// foo.call(user, 1, 6);
// foo.apply(user, [1, 6]);
//
// var bar = foo.bind(user);
// bar(1, 6);
// foo();

// var obj = {
//     prop: 'Hello!',
//     init() {
//         var btn = document.getElementById('btn');
//         // var _this = this;
//
//         // btn.addEventListener('click', this.method);
//         // btn.addEventListener('click', this.method.bind(this));
//         // btn.addEventListener('click', function () {
//         //     _this.method();
//         // });
//         btn.addEventListener('click', () => {
//             this.method();
//         });
//     },
//     method() {
//         console.log(this);
//     }
// }
//
// obj.init();

// function foo(a, b, ...params) {
//     console.log(arguments);
//     console.log(params);
//     // console.log([].includes.call(arguments, 8));
//     // console.log(Array.prototype.includes.call(arguments, 8));
//     console.log(params.includes(8));
// }
//
// foo(1, 6, 8, 5, 6);

// var foo = () => {
//     console.log(arguments);
// }
//
// foo(1, 4, 5);

// function getObject(name) {
//     var userName = name;
//
//     function getUserName() {
//         return userName;
//     }
//
//     return {
//         getName: getUserName,
//         setName: function (newName) {
//             userName = newName;
//         }
//     }
// }
//
// var obj = getObject('Vasya');
//
// console.log(obj);
// console.log(obj.getName());
// obj.setName('Petya');
// console.log(obj.getName());

// function add(a, b) {
//     return a + b;
// }
// function add(a) {
//     return function (b) {
//         return a + b;
//     };
// }

// console.log(add(1, 7));
// console.log(add(1)(7));

// var add1 = add(1);
//
// console.log(add1(7));

// console.log(add(a)(b)...(n)()); // => a + b + ... + n
// console.log(add(a)(b)...(n)); // => a + b + ... + n
