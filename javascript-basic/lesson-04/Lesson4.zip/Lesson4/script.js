// const obj = {};
// const obj = new Object();
// console.log(obj);
// function getPropName(someData) {
//     return someData + 'testing';
// }
//
// const myCar = {
//     manufacture: 'Toyota',
//     color: 'black',
//     'prop with space': 'qwerty',
//     [getPropName('some')]: '123',
// };

// delete myCar.color;
// console.log(myCar);

// console.log('color' in myCar);

// myCar.prop = 123;
// myCar.color = 'red';

// console.log(myCar['prop with space']);

// const userSelect = 'color';
//
// console.log(myCar[userSelect]);
// console.log(myCar['manufacture']);

// const myCar = {
//     manufacture: 'Toyota',
//     color: 'black',
//     engine: {
//         power: 200,
//         code: 'XXXX',
//     },
//     possibleColors: ['black', 'red', 'white', 'blue'],
//     // beep: function () {
//     //     console.log('Beep!');
//     // },
//     beep() {
//         console.log('Beep!');
//     },
//     [Symbol.iterator]: function* () {
//         for (const prop in myCar) {
//             yield myCar[prop];
//         }
//     }
// };

// myCar.beep();

// for (let i = 0; i < myCar.possibleColors.length; i++) {
//     console.log(myCar.possibleColors[i]);
// }

// console.log(Object.keys(myCar));

// const keys = Object.keys(myCar);
// for (let i = 0; i < keys.length; i++) {
//     console.log(myCar[keys[i]]);
// }

// for (const prop in myCar) {
//     console.log(prop, myCar[prop]);
// }

// for (const value of myCar) {
//     console.log(value);
// }

// function inc(a) {
//     ++a;
// }
//
// let a = 1;
//
// inc(a);
// console.log(a);

// const obj = {
//     num: 5,
// };
//
// function inc(obj) {
//     obj.num++;
// }
//
// inc(obj);
//
// console.log(obj.num);
// 'use strict';
// function getObject() {
//     return {
//         number: 5,
//         sayNumber() {
//             // console.log('Current number:', this.number);
//             console.log('Current this:', this);
//         }
//     }
// }
//
// const myObj = getObject();
// const mySayNumber = myObj.sayNumber;

// console.log(myObj);
// myObj.sayNumber();
// mySayNumber();
