// console.log(window.document);
// console.dir(document);

// поиск элементов
// console.log(document.getElementById('id-test'));
// console.log(document.getElementsByClassName('test-class'));
// console.log(document.getElementsByTagName('p'));

// console.log(document.querySelector('.test-class:last-child'));
// console.log(document.querySelectorAll('.test-class'));

// const pTags = document.querySelectorAll('p');
// for (let i = 0; i < pTags.length; i++) { // for of
//     console.dir(pTags[i]);
// }

// const h1Tag = document.querySelector('h1');
// console.log(h1Tag.textContent);
// console.log(h1Tag.innerText);
// console.log(h1Tag.innerHTML);

// h1Tag.innerHTML += '<i>!</i>';
// h1Tag.innerHTML = h1Tag.innerHTML + '<i>!</i>';
// h1Tag.textContent += '<i>!</i>';

// const demo = document.querySelector('#demo');

// BAD
// for (let i = 0; i < 10; i++) {
//     demo.innerHTML += '<div>Это элемент номер - ' + i + '</div>';
// }

// GOOD
// let HTMLString = '';
//
// for (let i = 0; i < 10; i++) {
//     HTMLString += '<div>Это элемент номер - ' + i + '</div>';
// }
//
// demo.innerHTML = HTMLString;

// styles
// const h1Tag = document.querySelector('h1');

// h1Tag.style.backgroundColor = 'yellow';
// console.log(h1Tag.style);
// console.log(getComputedStyle(h1Tag));

// создание
// const myDiv = document.createElement('div');
// const i = document.createElement('i');
//
// // работа с классами
// myDiv.className = 'my-class1 my-class2';
// myDiv.classList.add('my-class3');
// myDiv.classList.remove('my-class1');
// myDiv.classList.toggle('visible');
// console.log(myDiv.classList.contains('my-class2'));
//
// i.textContent = 'Hello!';
// myDiv.appendChild(i);
// document.body.appendChild(myDiv);
//
// console.log(myDiv);

// document.body.insertAdjacentHTML('beforebegin', '<div><i>Hello!</i></div>');
// document.body.insertAdjacentHTML('afterbegin', '<div><i>Hello!</i></div>');
// document.body.insertAdjacentHTML('beforeend', '<div><i>Hello!</i></div>');
// document.body.insertAdjacentHTML('afterend', '<div><i>Hello!</i></div>');

// const h1Tag = document.querySelector('h1');
// const h1Tag = document.querySelector('h1').cloneNode(true);
// const parentElement = document.getElementById('id-test');
// const refElement = document.querySelector('.test-class:last-child');
//
// setTimeout(() => {
//     parentElement.insertBefore(h1Tag, refElement);
// }, 3000);

// const h1Tag = document.querySelector('h1');
// h1Tag.remove();
// console.log(h1Tag);
// h1Tag.parentElement.removeChild(h1Tag);

// document.body.innerHTML = '';
// document.body.innerText = '';

// function start() {
//     hello();
//     bye();
// }
// function hello() {
//     alert('Hello!');
// }
// function bye() {
//     alert('Bye!');
// }
//
// const btn = document.querySelector('button');
// btn.onclick = start;
// btn.onclick = hello;
// btn.onclick = bye;

// btn.addEventListener('click', hello);
// btn.addEventListener('click', bye);
// btn.addEventListener('click', function () {
//     console.log('test');
// });
//
// btn.removeEventListener('click', bye);
// btn.removeEventListener('click', function () {
//     console.log('test');
// });
//
// // События документа
// window.addEventListener('load', function () {
//     //...
// });
// document.addEventListener('DOMContentLoaded', function () {
//     //...
// });
// window.addEventListener('beforeunload', function () {
//     //...
// });
