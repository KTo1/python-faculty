let number;
let attempts;

function resetGame() {
    attempts = 0;
    number = Math.floor(Math.random() * 100);
    console.log(number);
}

function tryGuessNumber() {
    const userAnswer = parseInt(prompt('Введите число от 0 до 100, для выхода наберите -1'));

    if (userAnswer === -1) return alert('Game Over');

    if (isNaN(userAnswer)) {
        alert('Необходимо ввести целое число от 0 до 100.');
        tryGuessNumber();
        return;
    }

    attempts++;

    if (userAnswer > number) alert('Введите число меньше');
    else if (userAnswer < number) alert('Введите число больше');
    else {
        alert(`Поздравляем! Вы угадали число с ${attempts} попытки(ок).`);

        if (!confirm('Хотите сыграть еще?')) return alert('Game Over');
        resetGame();
    }

    tryGuessNumber();
}

resetGame();
tryGuessNumber();
