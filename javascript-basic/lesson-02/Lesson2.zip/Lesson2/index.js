// let goodsCount = 10;

// if (goodsCount > 0) {
//     console.log('Количество товаров: ', goodsCount);
// } else {
//     console.log('Корзина пуста');
// }
// if (goodsCount > 0) console.log('Количество товаров: ', goodsCount);
// else console.log('Корзина пуста');

// goodsCount > 0 // условие
//     ? console.log('Количество товаров: ', goodsCount) // true
//     : console.log('Корзина пуста'); // false
//
// const message = goodsCount > 0
//     ? 'Количество товаров: ' + goodsCount // `Количество товаров: ${goodsCount}`
//     : 'Корзина пуста';
//
// console.log(message);

// const good = 'Яблоки';

// if (good === 'Бананы') {
//     console.log('Стоимость бананов 50р.');
// } else {
//     if (good === 'Манго') {
//         console.log('Стоимость манго 80р.');
//     } else {
//         if (good === 'Яблоки' || good === 'Груши') {
//             console.log('Стоимость яблок и груш 40р.');
//         } else {
//             console.log('Неизвестный фрукт');
//         }
//     }
// }

// if (good === 'Бананы') {
//     console.log('Стоимость бананов 50р.');
// } else if (good === 'Манго') {
//     console.log('Стоимость манго 80р.');
// } else if (good === 'Яблоки' || good === 'Груши') {
//     console.log('Стоимость яблок и груш 40р.');
// } else {
//     console.log('Неизвестный фрукт');
// }
// const good = 'Яблоки';

// switch (good) {
//     case "Бананы": console.log('Стоимость бананов 50р.'); break;
//     case "Манго": console.log('Стоимость манго 80р.'); break;
//     case "Яблоки":
//     case "Груши": console.log('Стоимость яблок и груш 40р.'); break;
//     default: console.log('Неизвестный фрукт');
// }

// const good = 'Яблоки';
//
// function sayPrice(good) {
//     switch (good) {
//         case "Бананы": console.log('Стоимость бананов 50р.'); break;
//         case "Манго": console.log('Стоимость манго 80р.'); break;
//         case "Яблоки":
//         case "Груши": console.log('Стоимость яблок и груш 40р.'); break;
//         default: console.log('Неизвестный фрукт');
//     }
// }
//
// sayPrice('Манго');
// sayPrice(good);
// sayPrice();

// function sayPrice(price = 'неизветна') {
//     console.log('Стоимость товара:', price);
// }
//
// sayPrice(1000);
// sayPrice();

// function getGoodPrice(good) {
//     switch (good) {
//         case "Бананы": return 50;
//         case "Манго": return 80;
//         case "Яблоки":
//         case "Груши": return 40;
//         default: return null;
//     }
// }

// const result = getGoodPrice('Бананы');
// const result = getGoodPrice('Бананы');
//
// // if (!isNaN(result)) console.log('ok!');
// if (result != null) console.log('ok!');
// else console.log('=(');

// function getGoodsPriceByCount(good, count = 1) {
//     const priceByGoodItem = getGoodPrice(good);
//
//     if (priceByGoodItem == null) return null;
//
//     return priceByGoodItem * count;
// }
//
// console.log(getGoodsPriceByCount('Бананы', 10));
// console.log(getGoodsPriceByCount('Груши', 5));
// console.log(getGoodsPriceByCount('Груши'));
// foo();
// function foo() {
//     console.log('test');
// }
// foo();

// const foo = () => {
//     console.log('foo');
// }
// const foo = function () {
//     console.log('foo');
// }

// foo();

// const foo = function (a) {
//     console.log(a, arguments);
// }
//
// foo(1, 'wert', true);

// function recursion(x) {
//     if (x <= 0 || !Number.isInteger(x)) return 'Задайте целое число больше 0';
//
//     if (x === 1) return '1';
//
//     return recursion(x - 1) + ' ' + x;
// }
//
// console.log(recursion(100));


